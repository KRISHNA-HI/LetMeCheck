import { createClient, SupabaseClient } from '@supabase/supabase-js';
import {
  Manga,
  UserProfile,
  UserLibraryEntry,
  UserProgress,
  UserMaterialProgress,
  UserNote,
  ReadingStatus,
  MaterialStatus
} from '../types';
import { localStorageService } from './storage';

const env = (import.meta as any).env || {};
const supabaseUrl = env.VITE_SUPABASE_URL || '';
const supabaseAnonKey = env.VITE_SUPABASE_PUBLISHABLE_KEY || env.VITE_SUPABASE_ANON_KEY || '';

export const isSupabaseConfigured = (): boolean => {
  return Boolean(
    supabaseUrl &&
    supabaseAnonKey &&
    supabaseUrl.startsWith('http') &&
    !supabaseUrl.includes('placeholder')
  );
};

export const supabase: SupabaseClient | null = isSupabaseConfigured()
  ? createClient(supabaseUrl, supabaseAnonKey, {
      auth: {
        persistSession: true,
        autoRefreshToken: true,
        detectSessionInUrl: true
      }
    })
  : null;

const UUID_REGEX = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

export const supabaseService = {
  isConfigured(): boolean {
    return isSupabaseConfigured();
  },

  // ----------------------------------------------------
  // AUTHENTICATION
  // ----------------------------------------------------
  async signUp(email: string, password: string, username: string) {
    if (!supabase) {
      return { user: null, error: new Error('Supabase client is not configured.') };
    }

    const { data, error } = await supabase.auth.signUp({
      email,
      password,
      options: {
        data: {
          username,
          display_name: username
        }
      }
    });

    if (error) return { user: null, error };
    return { user: data.user, error: null };
  },

  async signIn(email: string, password: string) {
    if (!supabase) {
      return { user: null, error: new Error('Supabase client is not configured.') };
    }

    const { data, error } = await supabase.auth.signInWithPassword({
      email,
      password
    });

    if (error) return { user: null, error };
    return { user: data.user, error: null };
  },

  async signOut() {
    localStorageService.clearUserData();
    if (!supabase) {
      return { error: null };
    }
    const { error } = await supabase.auth.signOut();
    return { error };
  },

  async resetPassword(email: string) {
    if (!supabase) {
      return { data: null, error: new Error('Supabase client is not configured.') };
    }
    const { data, error } = await supabase.auth.resetPasswordForEmail(email);
    return { data, error };
  },

  async getCurrentUser(): Promise<UserProfile | null> {
    if (!supabase) {
      return null;
    }

    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) {
        return null;
      }

      // Fetch profile row
      const { data: profile } = await supabase
        .from('profiles')
        .select('*')
        .eq('id', user.id)
        .maybeSingle();

      const userProfile: UserProfile = {
        id: user.id,
        email: user.email,
        username: profile?.username || user.user_metadata?.username || user.email?.split('@')[0] || 'User',
        display_name: profile?.display_name || user.user_metadata?.display_name || 'Reader',
        avatar_url: profile?.avatar_url || user.user_metadata?.avatar_url || '',
        created_at: profile?.created_at || user.created_at
      };

      localStorageService.setLocalUser(userProfile);
      return userProfile;
    } catch (e) {
      console.warn('getCurrentUser error:', e);
      return null;
    }
  },

  async updateProfile(userId: string, updates: Partial<UserProfile>) {
    if (!supabase) {
      return { data: null, error: new Error('Supabase client is not configured.') };
    }

    const { data, error } = await supabase
      .from('profiles')
      .update({
        display_name: updates.display_name,
        avatar_url: updates.avatar_url,
        updated_at: new Date().toISOString()
      })
      .eq('id', userId)
      .select()
      .single();

    if (!error && data) {
      const current = localStorageService.getLocalUser();
      if (current) {
        localStorageService.setLocalUser({ ...current, ...data });
      }
    }

    return { data, error };
  },

  // ----------------------------------------------------
  // MANGA METADATA CACHE & CANONICAL UUID RESOLVER
  // ----------------------------------------------------
  async getOrCreateManga(manga: Manga): Promise<Manga> {
    if (!supabase) {
      return manga;
    }

    try {
      const isMangaIdUuid = typeof manga.id === 'string' && UUID_REGEX.test(manga.id);
      const anilistId = manga.anilist_id || (typeof manga.id === 'number' ? manga.id : null);

      // 1. Check if manga already exists in database
      let existingMangaRow: any = null;

      if (isMangaIdUuid) {
        const { data } = await supabase.from('manga').select('*').eq('id', manga.id).maybeSingle();
        if (data) existingMangaRow = data;
      }

      if (!existingMangaRow && anilistId) {
        const { data } = await supabase.from('manga').select('*').eq('anilist_id', anilistId).maybeSingle();
        if (data) existingMangaRow = data;
      }

      if (!existingMangaRow && manga.title) {
        const { data } = await supabase.from('manga').select('*').eq('title', manga.title).maybeSingle();
        if (data) existingMangaRow = data;
      }

      // 2. If already in database, fetch its materials and return canonical Manga object
      if (existingMangaRow) {
        const { data: dbMaterials } = await supabase
          .from('manga_material')
          .select('*')
          .eq('manga_id', existingMangaRow.id);

        const materialsList = dbMaterials && dbMaterials.length > 0
          ? dbMaterials.map((m: any) => ({
              id: m.id,
              manga_id: m.manga_id,
              type: m.type,
              title: m.title,
              number: m.number,
              description: m.description,
              release_date: m.release_date,
              external_id: m.external_id,
              external_url: m.external_url
            }))
          : manga.materials;

        return {
          id: existingMangaRow.id, // Supabase UUID
          anilist_id: existingMangaRow.anilist_id,
          mangadex_id: existingMangaRow.mangadex_id,
          title: existingMangaRow.title,
          alternative_titles: existingMangaRow.alternative_titles || [],
          description: existingMangaRow.description || '',
          type: existingMangaRow.type || 'Manga',
          status: existingMangaRow.status || 'Ongoing',
          author: existingMangaRow.author || undefined,
          artist: existingMangaRow.artist || undefined,
          genres: existingMangaRow.genres || [],
          chapters: existingMangaRow.chapters,
          volumes: existingMangaRow.volumes,
          cover_url: existingMangaRow.cover_url,
          banner_url: existingMangaRow.banner_url,
          score: manga.score,
          popularity: manga.popularity,
          release_year: manga.release_year,
          source: existingMangaRow.source || 'AniList',
          materials: materialsList
        };
      }

      // 3. Insert fresh manga record into database WITHOUT id (let postgres generate UUID)
      const { data: inserted, error } = await supabase
        .from('manga')
        .insert({
          anilist_id: anilistId,
          mangadex_id: manga.mangadex_id || null,
          title: manga.title,
          alternative_titles: manga.alternative_titles || [],
          description: manga.description || '',
          type: manga.type || 'Manga',
          status: manga.status || 'Ongoing',
          author: manga.author || null,
          artist: manga.artist || null,
          genres: manga.genres || [],
          chapters: manga.chapters || null,
          volumes: manga.volumes || null,
          cover_url: manga.cover_url || '',
          banner_url: manga.banner_url || null,
          source: manga.source || 'AniList'
        })
        .select('*')
        .single();

      if (error || !inserted) {
        console.warn('Could not insert manga row into Supabase:', error);
        return manga;
      }

      // 4. Insert materials if provided
      let canonicalMaterials = manga.materials || [];
      if (canonicalMaterials.length > 0) {
        const matsToInsert = canonicalMaterials.map((m) => ({
          manga_id: inserted.id,
          type: m.type,
          title: m.title,
          number: m.number || null,
          description: m.description || null,
          release_date: m.release_date || null,
          external_id: m.external_id || (typeof m.id === 'string' && !UUID_REGEX.test(m.id) ? m.id : null),
          external_url: m.external_url || null
        }));

        const { data: insertedMats } = await supabase
          .from('manga_material')
          .upsert(matsToInsert, { onConflict: 'manga_id,external_id' })
          .select('*');

        if (insertedMats && insertedMats.length > 0) {
          canonicalMaterials = insertedMats.map((m: any) => ({
            id: m.id, // Supabase generated UUID
            manga_id: m.manga_id,
            type: m.type,
            title: m.title,
            number: m.number,
            description: m.description,
            release_date: m.release_date,
            external_id: m.external_id,
            external_url: m.external_url
          }));
        }
      }

      return {
        ...manga,
        id: inserted.id, // Supabase generated UUID
        anilist_id: inserted.anilist_id,
        materials: canonicalMaterials
      };
    } catch (err) {
      console.warn('getOrCreateManga exception:', err);
      return manga;
    }
  },

  async ensureMangaCached(manga: Manga): Promise<string> {
    const canonical = await this.getOrCreateManga(manga);
    return canonical.id;
  },

  // ----------------------------------------------------
  // USER LIBRARY
  // ----------------------------------------------------
  async getLibrary(userId: string): Promise<UserLibraryEntry[]> {
    if (!supabase) {
      return localStorageService.getLibrary();
    }

    try {
      const { data, error } = await supabase
        .from('user_library')
        .select(`
          id,
          user_id,
          manga_id,
          status,
          created_at,
          updated_at,
          manga:manga_id (
            id,
            anilist_id,
            title,
            alternative_titles,
            description,
            type,
            status,
            author,
            artist,
            genres,
            chapters,
            volumes,
            cover_url,
            banner_url,
            source
          )
        `)
        .eq('user_id', userId)
        .order('updated_at', { ascending: false });

      if (error) throw error;

      const formatted: UserLibraryEntry[] = (data || []).map((row: any) => ({
        id: row.id,
        user_id: row.user_id,
        manga_id: row.manga_id, // Always Supabase UUID
        status: row.status as ReadingStatus,
        created_at: row.created_at,
        updated_at: row.updated_at,
        manga: row.manga
          ? {
              ...row.manga,
              id: row.manga.id, // Supabase UUID
              anilist_id: row.manga.anilist_id
            }
          : undefined
      }));

      // Cache locally for fast offline access
      localStorageService.setLibrary(formatted);
      return formatted;
    } catch (err) {
      console.warn('Supabase getLibrary error, returning cached:', err);
      return localStorageService.getLibrary();
    }
  },

  async upsertLibraryEntry(
    userId: string,
    manga: Manga,
    status: ReadingStatus
  ): Promise<UserLibraryEntry> {
    let canonicalManga = manga;
    let dbMangaId = manga.id;

    if (supabase) {
      try {
        canonicalManga = await this.getOrCreateManga(manga);
        dbMangaId = canonicalManga.id;
      } catch (err) {
        console.warn('ensureMangaCached in upsertLibraryEntry failed:', err);
      }
    }

    const entry: UserLibraryEntry = {
      user_id: userId,
      manga_id: dbMangaId,
      status,
      manga: canonicalManga,
      updated_at: new Date().toISOString()
    };

    // Save locally
    localStorageService.saveLibraryEntry(entry);

    if (!supabase) return entry;

    try {
      const { data, error } = await supabase
        .from('user_library')
        .upsert(
          {
            user_id: userId,
            manga_id: dbMangaId,
            status,
            updated_at: new Date().toISOString()
          },
          { onConflict: 'user_id,manga_id' }
        )
        .select(`
          id,
          user_id,
          manga_id,
          status,
          created_at,
          updated_at
        `)
        .single();

      if (error) {
        console.warn('Supabase upsertLibraryEntry error:', error);
        return entry;
      }

      const fullEntry: UserLibraryEntry = {
        ...data,
        manga: canonicalManga
      };

      // Keep local store in sync with server row id
      localStorageService.saveLibraryEntry(fullEntry);
      return fullEntry;
    } catch (err) {
      console.warn('upsertLibraryEntry exception:', err);
      return entry;
    }
  },

  async removeLibraryEntry(userId: string, mangaId: string | number) {
    localStorageService.removeLibraryEntry(mangaId);

    if (!supabase) return;

    try {
      let dbId = mangaId.toString();
      if (typeof mangaId === 'number' || !UUID_REGEX.test(dbId)) {
        const { data } = await supabase
          .from('manga')
          .select('id')
          .eq('anilist_id', mangaId)
          .maybeSingle();
        if (data?.id) dbId = data.id;
      }

      await supabase
        .from('user_library')
        .delete()
        .eq('user_id', userId)
        .eq('manga_id', dbId);
    } catch (err) {
      console.warn('removeLibraryEntry error:', err);
    }
  },

  // ----------------------------------------------------
  // READING PROGRESS
  // ----------------------------------------------------
  async getProgress(userId: string, mangaId: string | number): Promise<UserProgress | null> {
    if (!supabase) {
      return localStorageService.getProgress(mangaId);
    }

    try {
      let dbId = mangaId.toString();
      if (typeof mangaId === 'number' || !UUID_REGEX.test(dbId)) {
        const { data } = await supabase
          .from('manga')
          .select('id')
          .eq('anilist_id', mangaId)
          .maybeSingle();
        if (data?.id) dbId = data.id;
      }

      const { data, error } = await supabase
        .from('user_progress')
        .select('*')
        .eq('user_id', userId)
        .eq('manga_id', dbId)
        .maybeSingle();

      if (error) throw error;
      return data || localStorageService.getProgress(mangaId);
    } catch {
      return localStorageService.getProgress(mangaId);
    }
  },

  async saveProgress(
    userId: string,
    mangaId: string | number,
    chaptersRead: number,
    volumesRead: number
  ): Promise<UserProgress> {
    const record: UserProgress = {
      user_id: userId,
      manga_id: mangaId.toString(),
      chapters_read: chaptersRead,
      volumes_read: volumesRead,
      updated_at: new Date().toISOString()
    };

    localStorageService.saveProgress(record);

    if (supabase) {
      try {
        let dbId = mangaId.toString();
        if (typeof mangaId === 'number' || !UUID_REGEX.test(dbId)) {
          const { data } = await supabase
            .from('manga')
            .select('id')
            .eq('anilist_id', mangaId)
            .maybeSingle();
          if (data?.id) dbId = data.id;
        }

        await supabase.from('user_progress').upsert(
          {
            user_id: userId,
            manga_id: dbId,
            chapters_read: chaptersRead,
            volumes_read: volumesRead,
            updated_at: new Date().toISOString()
          },
          { onConflict: 'user_id,manga_id' }
        );
      } catch (e) {
        console.warn('Supabase saveProgress failed:', e);
      }
    }

    return record;
  },

  // ----------------------------------------------------
  // MATERIAL PROGRESS
  // ----------------------------------------------------
  async getMaterialProgress(userId: string, materialId: string): Promise<UserMaterialProgress | null> {
    if (!supabase) {
      return localStorageService.getMaterialProgress(materialId);
    }

    try {
      const { data } = await supabase
        .from('user_material_progress')
        .select('*')
        .eq('user_id', userId)
        .eq('material_id', materialId)
        .maybeSingle();

      return data || localStorageService.getMaterialProgress(materialId);
    } catch {
      return localStorageService.getMaterialProgress(materialId);
    }
  },

  async saveMaterialProgress(
    userId: string,
    materialId: string,
    status: MaterialStatus,
    progress = 0
  ): Promise<UserMaterialProgress> {
    const record: UserMaterialProgress = {
      user_id: userId,
      material_id: materialId,
      status,
      progress,
      updated_at: new Date().toISOString()
    };

    localStorageService.saveMaterialProgress(record);

    if (supabase) {
      try {
        await supabase.from('user_material_progress').upsert(
          {
            user_id: userId,
            material_id: materialId,
            status,
            progress,
            updated_at: new Date().toISOString()
          },
          { onConflict: 'user_id,material_id' }
        );
      } catch (e) {
        console.warn('Supabase saveMaterialProgress failed:', e);
      }
    }

    return record;
  },

  // ----------------------------------------------------
  // FAVORITES
  // ----------------------------------------------------
  async getFavorites(userId: string): Promise<string[]> {
    if (!supabase) {
      return localStorageService.getFavorites();
    }

    try {
      const { data, error } = await supabase
        .from('favorites')
        .select(`
          manga_id,
          manga:manga_id (
            anilist_id
          )
        `)
        .eq('user_id', userId);

      if (error) throw error;

      if (data) {
        const idList: string[] = [];
        data.forEach((row: any) => {
          if (row.manga?.anilist_id) {
            idList.push(row.manga.anilist_id.toString());
          }
          idList.push(row.manga_id.toString());
        });
        localStorageService.setFavorites(idList);
        return idList;
      }
      return localStorageService.getFavorites();
    } catch {
      return localStorageService.getFavorites();
    }
  },

  async toggleFavorite(userId: string, manga: Manga): Promise<boolean> {
    const localRes = localStorageService.toggleFavorite(manga.id);

    if (supabase) {
      try {
        const dbMangaId = await this.ensureMangaCached(manga);
        if (localRes) {
          await supabase.from('favorites').upsert(
            {
              user_id: userId,
              manga_id: dbMangaId
            },
            { onConflict: 'user_id,manga_id' }
          );
        } else {
          await supabase
            .from('favorites')
            .delete()
            .eq('user_id', userId)
            .eq('manga_id', dbMangaId);
        }
      } catch (e) {
        console.warn('Supabase toggleFavorite failed:', e);
      }
    }

    return localRes;
  },

  // ----------------------------------------------------
  // NOTES
  // ----------------------------------------------------
  async getNote(userId: string, mangaId: string | number): Promise<UserNote | null> {
    if (!supabase) {
      return localStorageService.getNotes(mangaId);
    }

    try {
      let dbId = mangaId.toString();
      if (typeof mangaId === 'number' || !UUID_REGEX.test(dbId)) {
        const { data } = await supabase
          .from('manga')
          .select('id')
          .eq('anilist_id', mangaId)
          .maybeSingle();
        if (data?.id) dbId = data.id;
      }

      const { data } = await supabase
        .from('notes')
        .select('*')
        .eq('user_id', userId)
        .eq('manga_id', dbId)
        .maybeSingle();

      return data || localStorageService.getNotes(mangaId);
    } catch {
      return localStorageService.getNotes(mangaId);
    }
  },

  async saveNote(userId: string, mangaId: string | number, content: string): Promise<UserNote> {
    const note: UserNote = {
      user_id: userId,
      manga_id: mangaId.toString(),
      content,
      updated_at: new Date().toISOString()
    };

    localStorageService.saveNote(note);

    if (supabase) {
      try {
        let dbId = mangaId.toString();
        if (typeof mangaId === 'number' || !UUID_REGEX.test(dbId)) {
          const { data } = await supabase
            .from('manga')
            .select('id')
            .eq('anilist_id', mangaId)
            .maybeSingle();
          if (data?.id) dbId = data.id;
        }

        await supabase.from('notes').upsert(
          {
            user_id: userId,
            manga_id: dbId,
            content,
            updated_at: new Date().toISOString()
          },
          { onConflict: 'user_id,manga_id' }
        );
      } catch (e) {
        console.warn('Supabase saveNote failed:', e);
      }
    }

    return note;
  },

  async deleteNote(userId: string, mangaId: string | number): Promise<void> {
    localStorageService.deleteNote(mangaId);

    if (supabase) {
      try {
        let dbId = mangaId.toString();
        if (typeof mangaId === 'number' || !UUID_REGEX.test(dbId)) {
          const { data } = await supabase
            .from('manga')
            .select('id')
            .eq('anilist_id', mangaId)
            .maybeSingle();
          if (data?.id) dbId = data.id;
        }

        await supabase
          .from('notes')
          .delete()
          .eq('user_id', userId)
          .eq('manga_id', dbId);
      } catch (e) {
        console.warn('Supabase deleteNote failed:', e);
      }
    }
  }
};
